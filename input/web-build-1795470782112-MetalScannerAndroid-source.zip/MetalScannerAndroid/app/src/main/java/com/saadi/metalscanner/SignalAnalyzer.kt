package com.saadi.metalscanner

import kotlin.math.sqrt

/** Magnetic-field utilities only. These values cannot identify chemical composition. */
object SignalAnalyzer {
    fun magnitude(x: Float, y: Float, z: Float): Double =
        sqrt(x.toDouble() * x + y.toDouble() * y + z.toDouble() * z)

    fun delta(current: Double, baseline: Double): Double = kotlin.math.abs(current - baseline)

    fun label(delta: Double): String = when {
        delta >= 10.0 -> "Variation magnétique importante"
        delta >= 3.0 -> "Variation détectée"
        else -> "Variation faible"
    }
}
