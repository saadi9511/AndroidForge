package com.saadi.metalscanner

import org.junit.Assert.assertEquals
import org.junit.Test

class SignalAnalyzerTest {
    @Test fun magnitudeUsesThreeAxisVector() {
        assertEquals(13.0, SignalAnalyzer.magnitude(3f, 4f, 12f), 0.0001)
    }

    @Test fun deltaIsDistanceFromBaseline() {
        assertEquals(5.0, SignalAnalyzer.delta(45.0, 40.0), 0.0001)
    }

    @Test fun classifyDoesNotClaimMetalIdentity() {
        assertEquals("Variation magnétique importante", SignalAnalyzer.label(15.0))
        assertEquals("Variation faible", SignalAnalyzer.label(1.0))
    }
}
