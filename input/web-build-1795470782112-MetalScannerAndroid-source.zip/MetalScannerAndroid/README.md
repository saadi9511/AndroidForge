# Metal Scanner — Android

Prototype Android natif (Kotlin) utilisant le magnétomètre et l'état/lecture NFC du téléphone.

## Capacités
- Mesure du champ magnétique total en µT.
- Définition d'une référence puis affichage de l'écart.
- Enregistrement local en mémoire des dernières mesures pendant la session.
- Indication de disponibilité/activation NFC et lecture de l'identifiant technique d'un tag NFC présenté.

## Limites importantes
Cette application ne détecte pas de façon fiable l'or, l'argent ou le cuivre et ne peut pas déterminer la composition d'un bijou. Le magnétomètre réagit surtout aux champs magnétiques et aux matériaux ferromagnétiques. Le NFC sert à communiquer avec des tags NFC ; il n'est pas un analyseur de métaux. Les niveaux affichés sont des mesures de champ, pas une identification de matériau.

## Construire l'APK
1. Ouvrir ce dossier dans Android Studio (version récente avec Android SDK 35).
2. Laisser Gradle synchroniser les dépendances.
3. Exécuter `app/src/test` avec `testDebugUnitTest`.
4. Choisir **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. L'APK debug se trouvera dans `app/build/outputs/apk/debug/app-debug.apk`.

Application testée sur émulateur/appareil requis pour confirmer la présence réelle du magnétomètre et du NFC. Ce conteneur de génération ne possède pas Android SDK/Gradle et n'a pas accès au réseau pour les installer ; aucun APK compilé n'est donc fourni ici.
