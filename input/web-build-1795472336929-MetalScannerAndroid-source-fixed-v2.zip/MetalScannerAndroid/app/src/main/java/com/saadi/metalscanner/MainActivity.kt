package com.saadi.metalscanner

import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var magneticSensor: Sensor? = null
    private var nfcAdapter: NfcAdapter? = null
    private lateinit var fieldText: TextView
    private lateinit var deltaText: TextView
    private lateinit var statusText: TextView
    private lateinit var nfcText: TextView
    private lateinit var historyText: TextView
    private var baseline: Double? = null
    private val history = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        magneticSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        buildScreen()
        updateNfcStatus()
        handleNfcIntent(intent)
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xFF101923.toInt())
        }
        fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
            this.text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, 8, 0, 8)
        }
        root.addView(text("METAL SCANNER", 25f, 0xFFFFFFFF.toInt(), true))
        root.addView(text("Analyse expérimentale des capteurs", 14f, 0xFFB8C7D5.toInt()))
        fieldText = text("-- µT", 42f, 0xFF43D9D0.toInt(), true)
        root.addView(fieldText)
        root.addView(text("Champ magnétique total", 13f, 0xFFB8C7D5.toInt()))
        deltaText = text("Écart de référence : -- µT", 17f, 0xFFFFFFFF.toInt(), true)
        root.addView(deltaText)
        statusText = text("Initialisation du capteur…", 15f, 0xFF43D9D0.toInt())
        root.addView(statusText)
        val calibrate = Button(this).apply {
            text = "Définir la référence"
            setOnClickListener {
                val current = lastMagnitude
                if (current != null) {
                    this@MainActivity.baseline = current
                    deltaText.text = "Référence définie : %.2f µT".format(Locale.FRANCE, current)
                    addHistory("Référence : %.2f µT".format(Locale.FRANCE, current))
                }
            }
        }
        root.addView(calibrate)
        val save = Button(this).apply {
            text = "Enregistrer une mesure"
            setOnClickListener {
                val current = lastMagnitude
                if (current != null) addHistory("Mesure : %.2f µT | écart %.2f µT".format(Locale.FRANCE, current, this@MainActivity.baseline?.let { SignalAnalyzer.delta(current, it) } ?: 0.0))
            }
        }
        root.addView(save)
        nfcText = text("NFC : vérification…", 16f, 0xFFFFFFFF.toInt(), true)
        root.addView(nfcText)
        root.addView(text("Pour tester le NFC, approche une étiquette NFC compatible. Le NFC ne reconnaît pas la composition d'un métal.", 13f, 0xFFB8C7D5.toInt()))
        historyText = text("Historique\nAucune mesure enregistrée", 14f, 0xFFFFFFFF.toInt())
        root.addView(historyText)
        val warning = text("IMPORTANT : une variation magnétique ne prouve pas la présence d'or, d'argent ou de cuivre. Le téléphone ne peut pas certifier un bijou.", 13f, 0xFFFFCC80.toInt(), true)
        root.addView(warning)
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private var lastMagnitude: Double? = null

    override fun onResume() {
        super.onResume()
        magneticSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        updateNfcStatus()
        nfcAdapter?.takeIf { it.isEnabled }?.let { adapter ->
            val pending = PendingIntent.getActivity(
                this, 0, Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            val filters = arrayOf(IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED))
            adapter.enableForegroundDispatch(this, pending, filters, null)
        }
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        nfcAdapter?.disableForegroundDispatch(this)
        super.onPause()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_MAGNETIC_FIELD) return
        val value = SignalAnalyzer.magnitude(event.values[0], event.values[1], event.values[2])
        lastMagnitude = value
        fieldText.text = "%.2f µT".format(Locale.FRANCE, value)
        val ref = baseline
        if (ref == null) {
            deltaText.text = "Définis une référence pour comparer"
            statusText.text = "Capteur magnétique actif"
        } else {
            val d = SignalAnalyzer.delta(value, ref)
            deltaText.text = "Écart : %.2f µT".format(Locale.FRANCE, d)
            statusText.text = SignalAnalyzer.label(d)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun updateNfcStatus() {
        nfcText.text = when {
            nfcAdapter == null -> "NFC : non disponible sur cet appareil"
            !nfcAdapter!!.isEnabled -> "NFC : présent mais désactivé dans les réglages"
            else -> "NFC : activé — prêt à lire une étiquette compatible"
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNfcIntent(intent)
    }

    private fun handleNfcIntent(intent: Intent?) {
        val tag = intent?.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java) ?: return
        val id = tag.id.joinToString("") { "%02X".format(it) }
        addHistory("Tag NFC détecté : $id (identifiant technique, pas un métal)")
    }

    private fun addHistory(item: String) {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.FRANCE).format(Date())
        history.add(0, "$stamp — $item")
        historyText.text = "Historique\n" + history.take(12).joinToString("\n")
    }
}
